<!DOCTYPE html>
<html>
<head>
    <title>Throttle Rides</title>
</head>
<body>
    <h1>{{ config('app.name') }}</h1>
    
    <p style="font-size: 17px;">Welcome to our Throttle Rides group.</p>
    <a href="{{$data->url}}" style="width: 127px;height: 100px;color: white;display: block;height: 25px;background: #0cabbf;padding: 10px;text-align: center;border-radius: 5px;color: white;font-weight: bold;font-size: 17px;text-decoration: none;">Accept Invitation</a>
    <p>Thank you</p>
</body>
</html>
