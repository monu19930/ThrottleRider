<!-- Css FILES NOW -->
<link rel="stylesheet" href="{{ asset('public/rider/css/bootstrap.min.css')}}" />
<link rel="stylesheet" href="{{ asset('public/rider/css/style.css')}}" />
<link rel="stylesheet" href="{{ asset('public/rider/css/responsive.css')}}" />
<link rel="stylesheet" href="{{ asset('public/rider/css/slick.css')}}" />
<link href="{{ asset('public/rider/css/bootstrap-datepicker.css')}}" rel="stylesheet">
<link href="{{ asset('public/rider/css/sweetalert.min.css')}}" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('public/rider/css/jquery.multiselect.css')}}" />
<link rel="stylesheet" href="{{ asset('public/rider/css/jquery-ui.css')}}" />
<link rel="stylesheet" href="{{ asset('public/rider/css/email.multiple.css')}}">
